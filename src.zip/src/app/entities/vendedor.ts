export interface Vendedor {

  ra?: String,
  nome: String,
  cpf: String,
  area: String,
  dataAdmissao: Date,
  ativo: Boolean,
}
